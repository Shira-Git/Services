﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Net;
using System.Xml;
using System.Diagnostics;
using System.Configuration;

namespace email_for_damaged
{
    class Engine
    {
        

     
       // private HttpWebRequest request;
     //   private CookieContainer cookieContainer = new CookieContainer();

       

        public string mail_from = string.Empty;
        public string password = string.Empty;
        public string mail_to = string.Empty;
        public string pathMoveCoc = string.Empty;
        public string pathMoveInvoice = string.Empty;
        public string pathMoveDelivery = string.Empty;
        public string damagedFolder = string.Empty;
    




        XmlDocument doc = new XmlDocument();



        public Engine()
        {
            LoadGlobalParameters();
        }

        private void LoadGlobalParameters()
        {
            /* try
             {
                 // doc.Load("Config.xml");
                 // doc.Load(@"C:\Program Files\UpLoadDataService\UpLoadDataService\bin\Debug\Config.xml");

                 doc.Load(@"" + ConfigurationManager.AppSettings["pathXml"]);
             }
             catch (Exception ex)
             {

                 EventManager.WriteEventErrorMessage("can not load the doc", ex);
             }

             m_ConnectionString = doc.SelectSingleNode(@"Parameters/ConenctionString").InnerText + "&quot;";
             m_user = doc.SelectSingleNode(@"Parameters/Name").InnerText;
             m_pass = doc.SelectSingleNode(@"Parameters/Pass").InnerText;
             m_url = doc.SelectSingleNode(@"Parameters/Url").InnerText;

             //  m_nameView = doc.SelectSingleNode(@"Parameters/nameView").InnerText;

             m_folderpath = doc.SelectSingleNode(@"Parameters/folderpath").InnerText;
             ConnectionManager.ConnectionString = m_ConnectionString;
             ConnectionManager.Provider = doc.SelectSingleNode(@"Parameters/Provider").InnerText;

         }*/
            //data from config file
             mail_from = ConfigurationManager.AppSettings["mail_from"];
             password = ConfigurationManager.AppSettings["password"];
             mail_to = ConfigurationManager.AppSettings["mail_to"];
             pathMoveCoc = ConfigurationManager.AppSettings["moveToCoc"];
             pathMoveInvoice = ConfigurationManager.AppSettings["moveToInvoice"];
             pathMoveDelivery = ConfigurationManager.AppSettings["moveToDelivery"];
             damagedFolder = ConfigurationManager.AppSettings["damagedFolder"];
        }
    }
}
