﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace email_for_damaged
{
    class found_damaded
    {
    }
}*/
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net.Mail;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Configuration;
using System.Diagnostics;
using System.Xml;
using System.Data.Odbc;
using System.Collections.Specialized;




namespace email_for_damaged
{
    class found_damaded
    {
       // static int count;
        public static int returnCount()
        {
            int count = 0;
            using (XmlReader reader = XmlReader.Create("c:\\Program Files\\DMS Inc\\Dms-machsanToArchive\\statisticsForDammaged.xml"))
            {
                reader.Read();
                reader.ReadStartElement("Statitics");
                reader.ReadStartElement("Date");
                string today = reader.ReadString();
                reader.ReadEndElement();

                reader.ReadStartElement("NumOfDammaged");
                count = reader.ReadContentAsInt();
                reader.ReadEndElement();


            }
            return count;
        }
        public void file_damaged(string url, string mail_from, string password, string mail_to/*, DateTime last_file*/, string file_dir, string pathMove, string damagedFolder)
        {
            XmlDocument xd = new XmlDocument();
            xd.Load("C:\\Program Files\\DMS Inc\\Dms-machsanToArchive\\statisticsForDammaged.xml");
            XmlElement xmlEle1 = xd.DocumentElement["Date"];
            ResetStatistics(xmlEle1.InnerText);

            string files_day_damaged = ConfigurationManager.AppSettings["files_day_damaged"], url_file;
            //DateTime dateMax = last_file, time;
            DirectoryInfo d = new DirectoryInfo(System.IO.Path.GetFullPath(url));
            FileInfo[] Files = d.GetFiles("*.pdf");
            int count = returnCount();

            foreach (FileInfo file in Files)
            {
                //time = File.GetLastWriteTime(url + "\\" + file);
                //if (time > last_file)
                // {
                //save the max file that scan
                // if (time > dateMax)
                //    dateMax = time;
                // if no open in pdfreader -is damaged send email file.
                try
                {
                    url_file = url + "\\" + file.Name;
                    PdfReader reader = new PdfReader(url_file);
                    Document document = new Document(reader.GetPageSizeWithRotation(1)); ;
                    //try open pdfreader
                    document.Open();
                    reader.Close();

                    File.Move(file.FullName.ToString(), pathMove + "\\" + file.Name);

                }

                // if file damaged:
                catch (Exception ex)
                {
                    // data for mail
                    count++;
                    string title = "file damaged " + DateTime.Now + file.Name;
                    string massage = "file damaged from " + file_dir + " date " + DateTime.Now + "     name file     " + file.Name + "     massage    " + ex.Message;
                    string fileAttached = null;
                    if (ex.Message.Contains("PDF startxref not found"))
                    {
                        File.Move(file.FullName.ToString(), damagedFolder + "\\" + file.Name);
                        send_mail(mail_to, title, massage, fileAttached, mail_from, password, file_dir);
                        //File.AppendAllText(@files_day_damaged, file.Name + Environment.NewLine);
                        SaveStatistics(count);
                    }

                }
                //}

            }
            // return dateMax.AddSeconds(1);
            // SaveStatistics(count);
        }
        public void SaveStatistics(int count)
        {

            XmlDocument xd = new XmlDocument();
            xd.Load("C:\\Program Files\\DMS Inc\\Dms-machsanToArchive\\statisticsForDammaged.xml");
            XmlElement eleNew;
            eleNew = xd.CreateElement("dateOfDammaged1");
            eleNew.InnerText = DateTime.Now.ToString();
            xd.DocumentElement.AppendChild(eleNew);
            XmlElement xmlEle1 = xd.DocumentElement["NumOfDammaged"];
            xmlEle1.InnerText = count.ToString();

            xd.Save("C:\\Program Files\\DMS Inc\\Dms-machsanToArchive\\statisticsForDammaged.xml");





        }
        private void ResetStatistics(string today)
        {
            string now = DateTime.Today.ToString();
            if (now != today)
            {
                XmlDocument xd = new XmlDocument();
                xd.Load("C:\\Program Files\\DMS Inc\\Dms-machsanToArchive\\statisticsForDammaged.xml");
                XmlElement xmlEle1 = xd.DocumentElement["Date"];
                xmlEle1.InnerText = now;

                // XmlNode an=xd.DocumentElement["dateOfDammaged1"];
                // xd.GetElementsByTagName("dateOfDammaged1")
                // 
                XmlNodeList elemList = xd.GetElementsByTagName("dateOfDammaged1");
                for (int i = 0; i < elemList.Count; i++)
                {
                    XmlNode parent = elemList[0].ParentNode;
                    parent.RemoveChild(elemList[0]);
                }
                XmlElement xmlEle2 = xd.DocumentElement["NumOfDammaged"];
                xmlEle2.InnerText = "0";

                xd.Save("C:\\Program Files\\DMS Inc\\Dms-machsanToArchive\\statisticsForDammaged.xml");





            }
        }

        public void send_mail(string send_to, string title, string massage, string fileAttached, string mail_from, string password, string file_dir)
        {

            SmtpClient client = new SmtpClient();
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            client.Timeout = 10000;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;

            client.Credentials = new System.Net.NetworkCredential(mail_from, password);

            MailMessage mm = new MailMessage(mail_from, send_to, title, massage);
            if (fileAttached != null)
                mm.Attachments.Add(new Attachment(fileAttached));

            mm.BodyEncoding = UTF8Encoding.UTF8;
            mm.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

            try
            {
                client.Send(mm);
                string appendText = "file damaged send" + Environment.NewLine;
            }

            catch { }
        }

    }

}

