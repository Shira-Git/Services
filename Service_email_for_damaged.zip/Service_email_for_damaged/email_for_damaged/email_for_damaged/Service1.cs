﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace email_for_damaged
{
    public partial class Service1 : ServiceBase
    {
        bool degelStart = false, degel = false;
        string hour = "", minute = "";
        System.Timers.Timer runCommands_timer = new System.Timers.Timer();
        Engine _hashEngine;
        public Service1()
        {
            InitializeComponent();
        }
        static void Main()
        {
            System.Diagnostics.Debugger.Launch();
            System.ServiceProcess.ServiceBase[] ServicesToRun;
            ServicesToRun = new System.ServiceProcess.ServiceBase[] { new Service1() };
            System.ServiceProcess.ServiceBase.Run(ServicesToRun);

        }
        protected override void OnStart(string[] args)
        {
            degelStart = true;
            degel = true;
           System.Diagnostics.Debugger.Launch();          
            _hashEngine = new Engine();
            runCommands_timer.Interval = 1500;
            runCommands_timer.AutoReset = true;
            runCommands_timer.Elapsed += new System.Timers.ElapsedEventHandler(RunCommands_timer_Elapsed);
            runCommands_timer.Start();
            RunCommands_timer_Elapsed(null, null);        
        }
        

        protected override void OnStop()
        {
        }
        void RunCommands_timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            EventManager.WriteEventInfoMessage("elapsed now");
            if (degelStart == true)//this if is true only one time (after do start to service)
            {
                if (degel == true)
                {
                    runCommands_timer.Interval = 5000;
                    degel = false;
                }
                else
                {
                    runCommands_timer.Stop();
                    //Sets the timer to start working when it reaches real time according to time in app.config
                    //EventManager.WriteEventInfoMessage("start while");
                 //   while ((DateTime.Now.Hour.ToString() != hour || DateTime.Now.Minute.ToString() != minute)) { }
                 //   EventManager.WriteEventInfoMessage("finish while");
                    degelStart = false;
                    runCommands_timer.Interval = 1500;
                    runCommands_timer.Start();
                    RunCommands_timer_Elapsed(null, null);

                }
            }
            else
            {
               // DateTime last_file, file_return;
                found_damaded f = new found_damaded();
                EventManager.WriteEventInfoMessage("found_damaded start");

                //COC
                string url_txt_last_file = ConfigurationManager.AppSettings["url_txt_last_file_coc"];
                // last_file = DateTime.Parse(File.ReadAllText(@url_txt_last_file));

                string url = ConfigurationManager.AppSettings["pathCoc"];
                string file_dir = "COC";
                //file_return = 
                f.file_damaged(url, _hashEngine.mail_from, _hashEngine.password, _hashEngine.mail_to/*, last_file*/, file_dir, _hashEngine.pathMoveCoc, _hashEngine.damagedFolder);

                //write in config time for last file that send mail
                //File.WriteAllText(@url_txt_last_file, file_return.ToString());

                //delivery

                string url_txt_last_file2 = ConfigurationManager.AppSettings["url_txt_last_file_delivery"];
                //last_file = DateTime.Parse(File.ReadAllText(@url_txt_last_file2));

                string url2 = ConfigurationManager.AppSettings["pathDelivery"];
                file_dir = "DELIVERY";
                //file_return = 
                f.file_damaged(url2, _hashEngine.mail_from, _hashEngine.password, _hashEngine.mail_to/*, last_file*/, file_dir, _hashEngine.pathMoveDelivery, _hashEngine.damagedFolder);

                //write in config time for last file that send mail
                // File.WriteAllText(@url_txt_last_file2, file_return.ToString());

                // invoice
                string url_txt_last_file3 = ConfigurationManager.AppSettings["url_txt_last_file_invoice"];
                // last_file = DateTime.Parse(File.ReadAllText(@url_txt_last_file3));

                string url3 = ConfigurationManager.AppSettings["pathInvoice"];
                //file_return = 
                f.file_damaged(url3, _hashEngine.mail_from, _hashEngine.password, _hashEngine.mail_to/*, last_file*/, file_dir, _hashEngine.pathMoveInvoice, _hashEngine.damagedFolder);

                file_dir = "INVOICE";
                ////write in config time for last file that send mail
                // File.WriteAllText(@url_txt_last_file3, file_return.ToString());
                EventManager.WriteEventInfoMessage("found_damaded finish");
            }
        }
    }
}
